# Game Hub

A sleek, single-page website that lists and plays games from a JSON source.
Built for learning web development and showcasing HTML5 embedding.

## How to Use
1. Upload `index.html` to your GitHub repository.
2. Enable GitHub Pages in the repository settings.
3. Your site will be live at `https://<your-username>.github.io/<repo-name>/`.
